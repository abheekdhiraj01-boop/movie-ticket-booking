# Movie Ticket Booking System (Python + SQLite)

## Files
| File | Purpose |
|---|---|
| `app.py` | Command-line app (run this) |
| `database.py` | All database code (SQLite) |
| `schema.sql` | Database tables (movies, shows, bookings, booking_seats) |
| `movie_booking.db` | Ready-made database with 4 movies and 8 days of shows |
| `KANBAN.md` | Task board you can copy into Trello / Jira / GitHub Projects |
| `requirements.txt` | No packages needed |

## Run
```
python app.py
```
Needs Python 3.8+ only. If `movie_booking.db` is deleted, it is recreated automatically.

## Features
- Browse movies, pick a show (date, time, screen, free seats)
- Seat map with 3 price categories (Rs.150 / 220 / 350)
- Booking with ticket and unique ID (BKxxxxx)
- Double booking is blocked by a database UNIQUE rule
- View booking by ID, list bookings by phone number
- Cancel booking (only before show starts), seats become free again
- Admin panel (password in `app.py`, default `admin123`): revenue per movie + all bookings

## Database tables
- movies(id, title, genre, language, duration_min, rating)
- shows(id, movie_id, show_date, show_time, screen)
- bookings(id, customer_name, phone, show_id, seats, total_amount, status, created_at)
- booking_seats(id, booking_id, show_id, seat_no, price)  -- UNIQUE(show_id, seat_no)

## Customise
- Movies: edit `SEED_MOVIES` in `database.py` (or INSERT into `movies`)
- Show times: edit `SHOW_TIMES`
- Seat layout and prices: edit `ROWS`, `COLS`, `PRICE_BY_ROW`
